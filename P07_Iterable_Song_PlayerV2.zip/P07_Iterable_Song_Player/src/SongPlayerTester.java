import java.util.NoSuchElementException;

// File header comes here
/**
 * This class implements unit test methods to check the correctness of Song,
 * LinkedNode, SongPlayer ForwardSongIterator and BackwardSongIterator classes
 * in P07 Iterable Song Player assignment.
 *
 */
public class SongPlayerTester {

	/**
	 * Driver method defined in this SongPlayerTester class
	 * 
	 * @param args input arguments if any.
	 */
	public static void main(String args[]) {

		runAllTests();
		//boolean allUnitTestStatus = runAllUnitTests();
		//System.out.println("RunAllUnitTests pass - "+allUnitTestStatus);	
	}

	/**
	 * This method test and make use of the Song constructor, an accessor (getter)
	 * method, overridden method toString() and equal() method defined in the Song
	 * class.
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testSong() {
		Song song1 = new Song("Mojito", "Jay Chou", "3:05");
		Song song2 = new Song("Mojito", "Jay Chou", "2:10");
		Song song3 = new Song("Secret", "Jay Chou", "4:56");
		
		String song1Name = song1.getSongName();
		String song1Artist = song1.getArtist();
		String song1Duration = song1.getDuration();
		
		String song2Name = song2.getSongName();
		String song2Artist = song2.getArtist();
		String song2Duration = song2.getDuration();
		
		System.out.println("song 1 : "+song1);
		System.out.println("song 2 : "+song2);
		System.out.println("song 3 : "+song3);
		
		boolean result12 = song1.equals​(song2);
		boolean result13 = song1.equals​(song3);
		boolean testStatus = result12==true && result13==false;
		
		System.out.println("song 1 equals song 2 - "+result12);
		System.out.println("song 1 equals song 3 - "+result13);
		return testStatus;
	}

	/**
	 * This method test and make use of the LinkedNode constructor, an accessor
	 * (getter) method, and a mutator (setter) method defined in the LinkedCart
	 * class.
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testLinkedNode() {
		
		Song song11 = new Song("Mojito", "Jay Chou", "3:05");
		Song song21 = new Song("Mojito", "Jay Chou", "2:10");
		Song song31 = new Song("Secret", "Jay Chou", "4:56");
		
		LinkedNode node1 = new LinkedNode<Song>(null,song11,null);
		LinkedNode node2 = new LinkedNode<Song>(null,song21,null);
		LinkedNode node3 = new LinkedNode<Song>(null,song31,null);
		
		node1.setNext​(node2);
		node2.setPrev​(node1);
		node2.setNext​(node3);
		node3.setPrev​(node2);
		
		LinkedNode prevNode1 = node1.getPrev();
		LinkedNode nextNode3 = node3.getNext();
		
		Song song22 = (Song)node2.getData();
		Song song23 = (Song)node1.getNext().getData();
		Song song24 = (Song)node3.getPrev().getData();
		
		System.out.println("song 11 : "+song11);
		System.out.println("song 21 : "+song21);
		System.out.println("song 31 : "+song31);
		System.out.println("song 22 (from LinkedNode) : "+song22);
		System.out.println("song 23 (from LinkedNode>getNext) : "+song23);
		System.out.println("song 24 (from LinkedNode>getPrev) : "+song24);
		System.out.println("LinkedNode previous to Node 1 - "+prevNode1);
		System.out.println("LinkedNode next to Node 3 - "+nextNode3);
		
		boolean testStatus = song22.equals​(song23)&& song23.equals​(song24)
				&& prevNode1==null && nextNode3 == null;
		return testStatus;
	}

	/**
	 * This method checks for the correctness of addFirst(), addLast() and add(int
	 * index) method in SongPlayer class
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testSongPlayerAdd() {
		
		SongPlayer songList = new SongPlayer();
		Song song1 = new Song("Mojito", "Jay Chou", "3:05");
		Song song2 = new Song("Secret", "Jay Chou", "4:56");
		Song song3 = new Song("Clear Day", "Jay Chou", "4:59");
		Song song4 = new Song("Dragon Fist", "Jay Chou", "4:32");
		Song song5 = new Song("Out of Time", "The Weeknd", "3:34");
		Song song6 = new Song("StarBoy", "The Weeknd", "3:50");
		Song song7 = new Song("Save Your Tears", "The Weeknd", "3:35");
		Song song8 = new Song("Simple Love", "Jay Chou", "4:30");
		Song song9 = new Song("Superman Can’t Fly", "Jay Chou", "4:59");
		
		songList.addFirst(song1);
		songList.addFirst(song2);
		songList.addFirst(song3);
		songList.addFirst(song4);
		songList.addFirst(song5);
		songList.addLast​(song6);
		songList.addLast​(song7);
		songList.add​(0, song8);
		songList.add​(3, song9);
		Song song91 = songList.get​(3);
		boolean equals2 = song9.equals(song91);
		System.out.println("get(3) - song 9 - "+song91+" status - "+equals2);
		System.out.println(songList.play());
		
		boolean testStatus = songList.size()==9 && equals2;
		return testStatus;
	}

	/**
	 * This method checks for the correctness of getFirst(), getLast() and get(int
	 * index) method in SongPlayer class
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testSongPlayerGet() {
		SongPlayer songList = new SongPlayer();
		Song song1 = new Song("Mojito", "Jay Chou", "3:05");
		Song song2 = new Song("Secret", "Jay Chou", "4:56");
		Song song3 = new Song("StarBoy", "The Weeknd", "3:50");
		Song song4 = new Song("Simple Love", "Jay Chou", "4:30");
		Song song5 = new Song("Superman Can’t Fly", "Jay Chou", "4:59");
		
		songList.addFirst(song1);
		songList.addFirst(song2);
		songList.addLast​(song3);
		songList.add​(0,song4);
		songList.add​(songList.size(),song5);
		
		Song song31 = songList.get​(2);
		Song song51 = songList.get​(4);
		
		boolean equals1 = song1.equals(song31);
		System.out.println("get(2) - song3 - status : "+equals1);
		boolean equals2 = song5.equals(song51);
		System.out.println("get(2) - song5 - status : "+equals2);
		try {
			songList.get​(songList.size());
		} catch (IndexOutOfBoundsException iobe) {
			System.out.println("IndexOutOfBoundsException - test passed");
		}
		boolean testStatus = songList.size()==5;
		return testStatus;

	}

	/**
	 * This method checks for the correctness of removeFirst(), removeLast() and
	 * remove(int index) method in SongPlayer class
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testSongPlayerRemove() {
		SongPlayer songList = new SongPlayer();
		Song song1 = new Song("Mojito", "Jay Chou", "3:05");
		Song song2 = new Song("Secret", "Jay Chou", "4:56");
		Song song3 = new Song("StarBoy", "The Weeknd", "3:50");
		Song song4 = new Song("Simple Love", "Jay Chou", "4:30");
		Song song5 = new Song("Superman Can’t Fly", "Jay Chou", "4:59");
		Song song6 = new Song("Oh My God", "Adele", "3:45");
		Song song7 = new Song("Levitating", "Dua Lipa", "3:23");
		Song song8 = new Song("Be Kind", "Marshmello & Halsey", "2:53");
		
		songList.addFirst(song1);
		System.out.println("addFirst : "+song1);
		songList.addFirst(song2);
		System.out.println("addFirst : "+song2);
		songList.addLast​(song3);
		System.out.println("addLast : "+song3);
		songList.add​(0,song4);
		System.out.println("add(index - 0): "+song4);
		songList.add​(songList.size(),song5);
		System.out.println("add(index - "+songList.size()+") : "+song5);
		
		songList.addLast​(song6);
		songList.addLast​(song7);
		songList.add​(6,song8);
		
		System.out.println(songList.play());
		Song removedSong = songList.remove​(6);
		System.out.println("remove(6) "+removedSong);
		
		Song firstSong = songList.removeFirst();
		System.out.println("removeFirst - "+firstSong);
		System.out.println("getFirst : "+songList.getFirst());
		System.out.println("getLast : "+songList.getLast());
		
		Song lastSong = songList.removeLast();
		System.out.println("removeLast - "+lastSong);
		System.out.println("getFirst : "+songList.getFirst());
		System.out.println("getLast : "+songList.getLast());

		boolean testStatus = songList.size()==5;
		return testStatus;
	}
	
	/**
	 * This method checks for the correctness of iterator(),
	 * switchPlayingDirection() and String play() method in SongPlayer class
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testSongPlayerIterator() {
		SongPlayer songList = new SongPlayer();
		Song song1 = new Song("Mojito", "Jay Chou", "3:05");
		Song song2 = new Song("Secret", "Jay Chou", "4:56");
		Song song3 = new Song("StarBoy", "The Weeknd", "3:50");
		Song song4 = new Song("Simple Love", "Jay Chou", "4:30");
		Song song5 = new Song("Superman Can’t Fly", "Jay Chou", "4:59");
		
		songList.addFirst(song1);
		songList.addFirst(song2);
		songList.addLast​(song3);
		songList.add​(0,song4);
		songList.add​(songList.size(),song5);
		System.out.println();
		System.out.println("---------------- Play Forward -----------------");
		String songDataForward = songList.play();
		System.out.println(songDataForward);
		System.out.println();
		System.out.println("---------------- Play Backward -----------------");
		songList.switchPlayingDirection();
		String songDataBackward = songList.play();
		System.out.println(songDataBackward);
		System.out.println("------------------------------------------------");
		String[] songListForward = songDataForward.split(System.lineSeparator());
		String[] songListBackward = songDataBackward.split(System.lineSeparator());
		boolean testStatus = songListForward.length==songListBackward.length && songListForward[0].equals(song4.toString())
				&& songListBackward[0].equals(song5.toString());
		return testStatus;
	}

	/**
	 * This method checks for the correctness of contains(Object song), clear(),
	 * isEmpty()and size() method in SongPlayer class
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testSongPlayerCommonMethod() {
		SongPlayer songList = new SongPlayer();
		Song song1 = new Song("Mojito", "Jay Chou", "3:05");
		Song song2 = new Song("Secret", "Jay Chou", "4:56");
		Song song3 = new Song("StarBoy", "The Weeknd", "3:50");
		Song song4 = new Song("Simple Love", "Jay Chou", "4:30");
		Song song5 = new Song("Superman Can’t Fly", "Jay Chou", "4:59");
		
		boolean isEmpty1 = songList.isEmpty();
		int size1 = songList.size();
		System.out.println("Before adding songs : isEmtpy - "+isEmpty1+", size - "+size1);
		songList.addFirst(song1);
		songList.addFirst(song2);
		songList.addLast​(song3);
		songList.add​(0,song4);
		
		boolean contains1 = songList.contains​(song1);
		boolean contains4 = songList.contains​(song4);
		boolean contains5 = songList.contains​(song5);
		boolean isEmpty2 = songList.isEmpty();
		int size2 = songList.size();
		System.out.println("After adding songs : isEmtpy - "+isEmpty2+", size - "+size2);
		
		System.out.println("Songlist contains song1 (expected true) - "+contains1);
		System.out.println("Songlist contains song4 (expected true) - "+contains4);
		System.out.println("Songlist contains song5 (expected false) - "+contains5);
		songList.clear();
		boolean isEmpty3 = songList.isEmpty();
		int size3 = songList.size();
		System.out.println("After clearing songlist : isEmtpy - "+isEmpty3+", size - "+size3);
		
		return isEmpty1 && !isEmpty2 && isEmpty3 && contains1  &&contains4 && !contains5
				&& size1==0 && size2 == 4 && size3 == 0;
	}

	/**
	 * This method checks for the correctness of ForwardSongIterator class
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testForwardSongIterator() {
		SongPlayer songList = new SongPlayer();
		Song song1 = new Song("Mojito", "Jay Chou", "3:05");
		Song song2 = new Song("Secret", "Jay Chou", "4:56");
		Song song3 = new Song("StarBoy", "The Weeknd", "3:50");
		Song song4 = new Song("Simple Love", "Jay Chou", "4:30");
		Song song5 = new Song("Superman Can’t Fly", "Jay Chou", "4:59");
		
		songList.addFirst(song1);
		songList.addFirst(song2);
		songList.addLast​(song3);
		songList.add​(0,song4);
		
		ForwardSongIterator forwardIterator = (ForwardSongIterator)songList.iterator();
		boolean equals1 = song4.equals(forwardIterator.next());
		boolean equals2 = song2.equals(forwardIterator.next());
		boolean equals3 = song1.equals(forwardIterator.next());
		boolean equals4 = song3.equals(forwardIterator.next());

		System.out.println("ForwardIterator>next (song4) status - "+equals1);
		System.out.println("ForwardIterator>next (song2) status - "+equals2);
		System.out.println("ForwardIterator>next (song1) status - "+equals3);
		System.out.println("ForwardIterator>next (song3) status - "+equals4);
		boolean equals5 = false;
		try {
		 equals5 = song5.equals(forwardIterator.next()); 
		} catch (NoSuchElementException nsee) {
			System.out.println("ForwardIterator>next - NoSuchElementException - end of iterator");
		}
		System.out.println("ForwardIterator>next status - "+equals5);
		
		return equals1 && equals2 && equals3 && equals4 && !equals5;
	}

	/**
	 * This method checks for the correctness of BackwardSongIterator class
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testBackwardSongIterator() {
		SongPlayer songList = new SongPlayer();
		Song song1 = new Song("Mojito", "Jay Chou", "3:05");
		Song song2 = new Song("Secret", "Jay Chou", "4:56");
		Song song3 = new Song("StarBoy", "The Weeknd", "3:50");
		Song song4 = new Song("Simple Love", "Jay Chou", "4:30");
		Song song5 = new Song("Superman Can’t Fly", "Jay Chou", "4:59");
		
		songList.addFirst(song1);
		songList.addFirst(song2);
		songList.addLast​(song3);
		songList.add​(0,song4);
		
		songList.switchPlayingDirection();
		BackwardSongIterator backwardIterator = (BackwardSongIterator)songList.iterator();
		boolean equals1 = song3.equals(backwardIterator.next());
		boolean equals2 = song1.equals(backwardIterator.next());
		boolean equals3 = song2.equals(backwardIterator.next());
		boolean equals4 = song4.equals(backwardIterator.next());

		System.out.println("BackwardIterator>next (song3) status - "+equals1);
		System.out.println("BackwardIterator>next (song1) status - "+equals2);
		System.out.println("BackwardIterator>next (song2) status - "+equals3);
		System.out.println("BackwardIterator>next (song4) status - "+equals4);
		boolean equals5 = false;
		try {
		 equals5 = song5.equals(backwardIterator.next()); 
		} catch (NoSuchElementException nsee) {
			System.out.println("BackwardIterator>next - NoSuchElementException - end of iterator");
		}
		System.out.println("BackwardIterator>next status - "+equals5);
		
		return equals1 && equals2 && equals3 && equals4 && !equals5;
	}

	/**
	 * This method calls all the test methods defined and implemented in your
	 * SongPlayerTester class.
	 * 
	 * @return true if all the test methods defined in this class pass, and false
	 *         otherwise.
	 */
	public static boolean runAllUnitTests() {
		System.out.println("-------------------- testSong ----------------------------");
		boolean testSongStatus = testSong();	
		System.out.println("testSong unit test pass - "+testSongStatus);
		System.out.println();
		
		System.out.println("----------------------- testLinkedNode -------------------------");
		boolean testLinkedNodeStatus = testLinkedNode();	
		System.out.println("testLinkedNode unit test pass - "+testLinkedNodeStatus);
		System.out.println();
		
		System.out.println("----------------------- testSongPlayerAdd -------------------------");
		boolean testSongPlayerAddStatus = testSongPlayerAdd();	
		System.out.println("testSongPlayerAdd unit test pass - "+testSongPlayerAddStatus);
		System.out.println();

		System.out.println("----------------------- testSongPlayerGet -------------------------");
		boolean testSongPlayerGetStatus = testSongPlayerGet();	
		System.out.println("testSongPlayerGet unit test pass - "+testSongPlayerGetStatus);
		System.out.println();
		
		System.out.println("----------------------- testSongPlayerRemove -------------------------");
		boolean testSongPlayerRemoveStatus = testSongPlayerRemove();	
		System.out.println("testSongPlayerRemove unit test pass - "+testSongPlayerRemoveStatus);
		System.out.println();
		
		System.out.println("----------------------- testSongPlayerIterator -------------------------");
		boolean testSongPlayerIteratorStatus = testSongPlayerIterator();	
		System.out.println("testSongPlayerIterator unit test pass - "+testSongPlayerIteratorStatus);
		System.out.println();
		
		System.out.println("----------------------- testSongPlayerCommonMethod -------------------------");
		boolean testSongPlayerCommonMethodStatus = testSongPlayerCommonMethod();	
		System.out.println("testSongPlayerCommonMethod unit test pass - "+testSongPlayerCommonMethodStatus);
		System.out.println();	
		
		System.out.println("----------------------- testForwardSongIterator -------------------------");
		boolean testForwardSongIteratorStatus = testForwardSongIterator();	
		System.out.println("testForwardSongIterator unit test pass - "+testForwardSongIteratorStatus);
		System.out.println();	
		
		System.out.println("----------------------- testBackwardSongIterator -------------------------");
		boolean testBackwardSongIteratorStatus = testBackwardSongIterator();	
		System.out.println("testBackwardSongIterator unit test pass - "+testBackwardSongIteratorStatus);
		System.out.println();
		
		boolean allTestStatus = testSongStatus && testLinkedNodeStatus && testSongPlayerAddStatus && testSongPlayerGetStatus
				&& testSongPlayerRemoveStatus && testSongPlayerIteratorStatus && testSongPlayerCommonMethodStatus
				&& testForwardSongIteratorStatus && testBackwardSongIteratorStatus;
		return allTestStatus;
	}
	
	public static void runAllTests() {
		SongPlayer songList = new SongPlayer();
		songList.addFirst(new Song("Mojito", "Jay Chou", "3:05"));
		songList.addFirst(new Song("Secret", "Jay Chou", "4:56"));
		songList.addFirst(new Song("Clear Day", "Jay Chou", "4:59"));
		songList.addFirst(new Song("Dragon Fist", "Jay Chou", "4:32"));
		songList.addFirst(new Song("Out of Time", "The Weeknd", "3:34"));
		songList.addLast​(new Song("StarBoy", "The Weeknd", "3:50"));
		songList.addLast​(new Song("Save Your Tears", "The Weeknd", "3:35"));
		songList.add​(1, new Song("Simple Love", "Jay Chou", "4:30"));
		songList.add​(2, new Song("Superman Can’t Fly", "Jay Chou", "4:59"));
		songList.addLast​(new Song("Oh My God", "Adele", "3:45"));
		songList.addLast​(new Song("Levitating", "Dua Lipa", "3:23"));
		songList.add​(6, new Song("Be Kind", "Marshmello & Halsey", "2:53"));
		System.out.println("---------------- Play Forward -----------------");
		System.out.println(songList.play());
		System.out.println("------------------------------------------------");
		System.out.println(
				"songList.remove(6) -- Be Kind -- removed\n" + "songList.removeFirst(); -- Out of Time -- removed\n"
						+ "songList.removeLast(); -- Levitating -- removed\n");
		songList.remove​(6);
		songList.removeFirst();
		songList.removeLast();
		System.out.println("---------------- Play Forward -----------------");
		System.out.println(songList.play());
		System.out.println("------------------------------------------------");
		Song oneSong = new Song("Mojito", "Jay Chou", "3:05");
		System.out.print("songList.contains(new Song(\"Mojito\", \"Jay Chou\", \"3:05\"): ");
		System.out.println(songList.contains​(oneSong));
		System.out.println();
		System.out.println("songList.size(): " + songList.size());
		System.out.println();
		System.out.print("songList.contains(new Song(\"Be Kind\", \"Marshmello & Halsey\", \"2:53\"): ");
		oneSong = new Song("Be Kind", "Marshmello & Halsey", "2:53");
		System.out.println(songList.contains​(oneSong));
		System.out.println();
		System.out.println("---------------- Play Forward -----------------");
		System.out.println(songList.play());
		System.out.println();
		System.out.println("---------------- Play Backward -----------------");
		songList.switchPlayingDirection();
		System.out.println(songList.play());
		System.out.println("------------------------------------------------");
	}

}