import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Song Player
 * 
 * @author Rishita
 *
 */
public class SongPlayer extends java.lang.Object implements java.lang.Iterable<Song> {

	private int size; // size of the list
	private LinkedNode<Song> head; // head of this doubly linked list
	private LinkedNode<Song> tail; // tail of this doubly linked list
	private boolean playingBackward = false; // true if this song player is reading the list backward

	/**
	 * Creates a new instance of song player which contains zero songs and set by
	 * default to play songs in the forward direction.
	 */
	public SongPlayer() {
		size = 0;
		head = null;
		tail = null;
		playingBackward = false;
	}

	/**
	 * Adds Song as First Song
	 * 
	 * @param oneSong- the song that is going to be added to the head of this doubly
	 *                 linked list of songs
	 * @throws java.lang.NullPointerException - with a descriptive error message if
	 *                                        the passed oneSong is null
	 */
	public void addFirst(Song oneSong) {
		if (oneSong == null)
			throw new NullPointerException("NullPointerException - Song to be added is null.");
		LinkedNode songNode = new LinkedNode<Song>(null, oneSong, null);
		if (head == null) {
			head = songNode;
			tail = songNode;
			head.setPrev​(null);
			tail.setNext​(null);
		} else {
			songNode.setNext​(head);
			head.setPrev​(songNode);
			head = songNode;
		}
		size++;
	}

	/**
	 * Adds a Song as Last Song
	 * 
	 * @param oneSong - the song that is going to be added to the tail of this
	 *                doubly linked list of songs
	 * @throws java.lang.NullPointerException - with a descriptive error message if
	 *                                        the passed oneSong is null
	 */
	public void addLast​(Song oneSong) {
		if (oneSong == null)
			throw new NullPointerException("NullPointerException - Song to be added is null.");
		LinkedNode songNode = new LinkedNode<Song>(null, oneSong, null);
		if (head == null) {
			head = songNode;
			tail = songNode;
			head.setPrev​(null);
			tail.setNext​(null);
		} else {
			songNode.setPrev​(tail);
			tail.setNext​(songNode);
			tail = songNode;
		}
		size++;

	}

	/**
	 * Adds Song at a given position/order within this collection of songs
	 * 
	 * @param index   - the given index where the new song will be added
	 * @param oneSong - the song that is going to be added
	 * @throws java.lang.NullPointerException      - with a descriptive error
	 *                                             message if the passed oneSong is
	 *                                             null
	 * @throws java.lang.IndexOutOfBoundsException - with a descriptive error
	 *                                             message if index is out of the 0
	 *                                             .. size() range
	 */
	public void add​(int index, Song oneSong) {
		if (oneSong == null)
			throw new NullPointerException("NullPointerException - Song to be added is null.");
		if (index < 0 || index > size())
			throw new IndexOutOfBoundsException(
					"Index passed - " + index + " is OutOfBounds. SongPlayer doublelink Size - " + size());
		if (index == 0)
			this.addFirst(oneSong);
		else if (index == size())
			this.addLast​(oneSong);
		else {
			LinkedNode<Song> targetNode = getLinkedNode(index);
			LinkedNode<Song> prevNode = targetNode.getPrev();

			LinkedNode<Song> newNode = new LinkedNode<Song>(null, oneSong, null);
			prevNode.setNext​(newNode);
			newNode.setPrev​(prevNode);
			newNode.setNext​(targetNode);
			targetNode.setPrev​(newNode);
			size++;
		}
		
	}

	/**
	 * Returns the first Song in this list.
	 * 
	 * @return the Song at the head of this list
	 * @throws java.util.NoSuchElementException - with a descriptive error message
	 *                                          if this list is empty
	 */
	public Song getFirst() {
		if (isEmpty()) {
			throw new NoSuchElementException("SongPlayer list is empty. Add a song before getting first song.");
		}
		ForwardSongIterator fsi = new ForwardSongIterator(head);
		return fsi.next();
	}

	/**
	 * Returns the last Song in this list.
	 * 
	 * @return the Song at the tail of this list
	 * @throws java.util.NoSuchElementException - with a descriptive error message
	 *                                          if this list is empty
	 */
	public Song getLast() {
		if (isEmpty()) {
			throw new NoSuchElementException("SongPlayer list is empty. Add a song before getting last song.");
		}
		BackwardSongIterator bsi = new BackwardSongIterator(tail);
		return bsi.next();
	}

	/**
	 * Returns the song at the specified position in this list.
	 * 
	 * @param index - index of the song to return
	 * @return the song at the specified position in this list
	 * @throws java.lang.IndexOutOfBoundsException - with a descriptive error
	 *                                             message if index is out of the 0
	 *                                             .. size()-1 range
	 */
	public Song get​(int index) {
		LinkedNode<Song> targetNode = getLinkedNode(index);
		return targetNode.getData();
	}

	private LinkedNode<Song> getLinkedNode(int index) {
		if (index < 0 || index > size() - 1)
			throw new IndexOutOfBoundsException(
					"IndexOutOfBoundsException : index - " + index + " is outside (0," + (size() - 1) + ") range");
		LinkedNode targetNode = head;

		for (int i = 0; i < index; i++) {
			targetNode = targetNode.getNext();
		}
		return targetNode;
	}

	/**
	 * Removes and returns the first song from this list.
	 * 
	 * @return the first song from this list
	 * @throws java.util.NoSuchElementException - with a descriptive error message
	 *                                          if this list is empty
	 */
	public Song removeFirst() {
		if (this.isEmpty())
			throw new NoSuchElementException("SongPlayer list is empty");
		LinkedNode songNode = head;
		head = songNode.getNext();
		head.setPrev​(null);
		size--;
		return (Song) songNode.getData();
	}

	/**
	 * Removes and returns the last song from this list.
	 * 
	 * @return the last song from this list
	 * @throws java.util.NoSuchElementException - with a descriptive error message
	 *                                          if this list is empty
	 */
	public Song removeLast() {
		if (this.isEmpty())
			throw new NoSuchElementException("SongPlayer list is empty");
		LinkedNode songNode = tail;
		tail = songNode.getPrev();
		tail.setNext​(null);
		size--;
		return (Song) songNode.getData();
	}

	/**
	 * Removes the song at the specified position in this list and returns the song
	 * that was removed from the list. The order of precedence of the other songs in
	 * the list should not be modified.
	 * 
	 * @param index - the index of the song to be removed
	 * @return the song previously at the specified position
	 * @throws java.lang.IndexOutOfBoundsException - with a descriptive error
	 *                                             message if index is out of the 0
	 *                                             .. size()-1 range
	 */
	public Song remove​(int index) {

		Song removedSong = null;
		if (index < 0 || index > size()-1)
			throw new IndexOutOfBoundsException(
					"Index passed - " + index + " is OutOfBounds. SongPlayer doublelink Size - " + (size()-1));
		if (index == 0)
			removedSong = this.removeFirst();
		else if (index == size()-1)
			removedSong = this.removeLast();
		else {
			LinkedNode<Song> targetNode = getLinkedNode(index);
			LinkedNode<Song> prevNode = targetNode.getPrev();
			LinkedNode<Song> nextNode = targetNode.getNext();

			prevNode.setNext​(nextNode);
			nextNode.setPrev​(prevNode);
			removedSong = targetNode.getData();
			size--;
		}
		
		return removedSong;
	}

	/**
	 * Returns true if this list contains a match with the specified song. More
	 * formally, returns true if and only if this list contains at least one song e
	 * such that Objects.equals(o, e).
	 * 
	 * @param o - song whose presence in this list is to be tested
	 * @return true if this list contains the specified song
	 */
	public boolean contains​(Song o) {
		boolean result = false;
		for (LinkedNode<Song> node = head; node != null; node = node.getNext()) {
			if (o != null && o.equals​(node.getData()))
				result = true;
		}
		return result;
	}

	/**
	 * Removes all of the songs from this list. The list will be empty after this
	 * call returns.
	 */
	public void clear() {
		size = 0;
		head = null;
		tail = null;
		playingBackward = false;

	}

	/**
	 * Returns true if this list is empty.
	 * 
	 * @return true if this list is empty
	 */
	public boolean isEmpty() {
		return (size == 0);
	}

	/**
	 * Returns the number of songs in this list.
	 * 
	 * @return the number of songs in this list
	 */
	public int size() {
		return size;
	}

	/**
	 * Returns an iterator to iterate through the songs in this list with respect to
	 * current playing direction of this song player (either in the forward or in
	 * the backward direction)
	 * 
	 * @returns an Iterator to traverse the list of songs in this SongPlayer with
	 *          respect to the current playing direction specified by the
	 *          playingBackward data field.
	 */
	public java.util.Iterator<Song> iterator() {
		if (playingBackward)
			return new BackwardSongIterator(tail);
		else
			return new ForwardSongIterator(head);
	}

	/**
	 * Mutator of the playingDirection of this song player. It switches the playing
	 * direction by setting playingBackward to its opposite value.
	 */
	public void switchPlayingDirection() {
		playingBackward = !playingBackward;
	}

	/**
	 * Plays the songs in this song player in the current playing direction. This
	 * method MUST be implemented using an enhanced for-each loop.
	 * 
	 * @return a String representation of the songs in this song player. String
	 *         representations of each song are separated by a newline. If this song
	 *         player is empty, this method returns an empty string.
	 */
	public java.lang.String play() {
		StringBuilder songData = new StringBuilder(64);
		Iterator songListIterator = this.iterator();

		for (int i = 0; songListIterator.hasNext(); i++) {
			songData.append(songListIterator.next());
			songData.append(System.lineSeparator());
		}

		return songData.toString();
	}
}
