import java.util.NoSuchElementException;

/**
 * 
 * @author Rishita This class models an iterator to play songs in the reverse
 *         backward direction from a doubly linked list of songs
 */
public class BackwardSongIterator extends java.lang.Object implements java.util.Iterator<Song> {

	private LinkedNode<Song> next; // reference to the next linked node in a list of nodes

	/**
	 * Creates a new iterator which iterates through songs in back/tail to
	 * front/head order
	 * 
	 * @param last - reference to the tail of a doubly linked list of songs
	 */
	public BackwardSongIterator(LinkedNode<Song> last) {
		this.next = last;
	}

	/**
	 * Checks whether there are more songs to return in the reverse order hasNext in
	 * interface java.util.Iterator<Song> true if there are more songs to return in
	 * the reverse order
	 */
	@Override
	public boolean hasNext() {
		if(next != null) {			
		//if(next != null && next.getPrev() != null)
			return true;
		}
		else
			return false;
	}

	/**
	 * Returns the next song in the iteration next in interface
	 * java.util.Iterator<Song>
	 * 
	 * @throws java.util.NoSuchElementException - with a descriptive error message
	 *                                          if there are no more songs to return
	 *                                          in the reverse order (meaning if
	 *                                          this.hasNext() returns false)
	 */
	@Override
	public Song next() {
		if(this.hasNext()) {
			Song currentSong = next.getData();
			next = next.getPrev();
			return currentSong;
			//return next.getNext().getData();
		}
		else
			throw new NoSuchElementException("There is no next song left");
	}

}
