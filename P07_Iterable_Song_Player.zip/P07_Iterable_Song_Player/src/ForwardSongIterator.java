import java.util.NoSuchElementException;

/**
 * This class models an iterator to play songs in the forward direction from a
 * doubly linked list of songs
 * 
 * @author Rishita
 *
 */
public class ForwardSongIterator extends java.lang.Object implements java.util.Iterator<Song> {

	private LinkedNode<Song> next; // reference to the next linked node in a list of nodes.

	/**
	 * Creates a new iterator which iterates through songs in front/head to
	 * back/tail order
	 * 
	 * @param first - reference to the head of a doubly linked list of songs
	 */
	public ForwardSongIterator(LinkedNode<Song> first) {
		this.next = first;
	}

	/**
	 * Checks whether there are more songs to return hasNext in interface
	 * java.util.Iterator<Song>
	 * 
	 * @returns true if there are more songs to return
	 */
	@Override
	public boolean hasNext() {

		if(next !=null)
		//if(next !=null && next.getNext() != null)
			return true;
		else
			return false;
	}

	/**
	 * Returns the next song in the iteration next in interface
	 * java.util.Iterator<Song>
	 * 
	 * @returns java.util.NoSuchElementException - with a descriptive error message
	 *          if there are no more songs to return in the reverse order (meaning
	 *          if this.hasNext() returns false)
	 */
	@Override
	public Song next() {
		if(this.hasNext())
			return next.getData();
			//return next.getNext().getData();
		else
			throw new NoSuchElementException("There is no next song left");
	}

}
