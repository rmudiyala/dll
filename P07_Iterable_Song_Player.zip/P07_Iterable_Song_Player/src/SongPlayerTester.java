// File header comes here
/**
 * This class implements unit test methods to check the correctness of Song,
 * LinkedNode, SongPlayer ForwardSongIterator and BackwardSongIterator classes
 * in P07 Iterable Song Player assignment.
 *
 */
public class SongPlayerTester {

	/**
	 * Driver method defined in this SongPlayerTester class
	 * 
	 * @param args input arguments if any.
	 */
	public static void main(String args[]) {
		
		System.out.println("-------------------- testSong ----------------------------");
		boolean testSongStatus = testSong();	
		System.out.println("testSong unit test pass - "+testSongStatus);
		System.out.println();
		
		System.out.println("----------------------- testLinkedNode -------------------------");
		boolean testLinkedNodeStatus = testLinkedNode();	
		System.out.println("testLinkedNode unit test pass - "+testLinkedNodeStatus);
		System.out.println();
		
		System.out.println("----------------------- testSongPlayerAdd -------------------------");
		boolean testSongPlayerAddStatus = testSongPlayerAdd();	
		System.out.println("testSongPlayerAdd unit test pass - "+testSongPlayerAddStatus);
		System.out.println();

		System.out.println("----------------------- testSongPlayerGet -------------------------");
		boolean testSongPlayerGetStatus = testSongPlayerGet();	
		System.out.println("testSongPlayerGet unit test pass - "+testSongPlayerGetStatus);
		System.out.println();
		
		System.out.println("----------------------- testSongPlayerRemove -------------------------");
		boolean testSongPlayerRemoveStatus = testSongPlayerRemove();	
		System.out.println("testSongPlayerRemove unit test pass - "+testSongPlayerRemoveStatus);
		System.out.println();
	}
	
	public static void testSongPlayer() {
		SongPlayer songList = new SongPlayer();
		songList.addFirst(new Song("Mojito", "Jay Chou", "3:05"));
		songList.addFirst(new Song("Secret", "Jay Chou", "4:56"));
		songList.addFirst(new Song("Clear Day", "Jay Chou", "4:59"));
		songList.addFirst(new Song("Dragon Fist", "Jay Chou", "4:32"));
		songList.addFirst(new Song("Out of Time", "The Weeknd", "3:34"));
		songList.addLast​(new Song("StarBoy", "The Weeknd", "3:50"));
		songList.addLast​(new Song("Save Your Tears", "The Weeknd", "3:35"));
		songList.add​(1, new Song("Simple Love", "Jay Chou", "4:30"));
		songList.add​(2, new Song("Superman Can’t Fly", "Jay Chou", "4:59"));
		songList.addLast​(new Song("Oh My God", "Adele", "3:45"));
		songList.addLast​(new Song("Levitating", "Dua Lipa", "3:23"));
		songList.add​(6, new Song("Be Kind", "Marshmello & Halsey", "2:53"));
		System.out.println("---------------- Play Forward -----------------");
		System.out.println(songList.play());
		System.out.println("------------------------------------------------");
		System.out.println(
				"songList.remove(6) -- Be Kind -- removed\n" + "songList.removeFirst(); -- Out of Time -- removed\n"
						+ "songList.removeLast(); -- Levitating -- removed\n");
		songList.remove​(6);
		songList.removeFirst();
		songList.removeLast();
		System.out.println("---------------- Play Forward -----------------");
		System.out.println(songList.play());
		System.out.println("------------------------------------------------");
		Song oneSong = new Song("Mojito", "Jay Chou", "3:05");
		System.out.print("songList.contains(new Song(\"Mojito\", \"Jay Chou\", \"3:05\"): ");
		System.out.println(songList.contains​(oneSong));
		System.out.println();
		System.out.println("songList.size(): " + songList.size());
		System.out.println();
		System.out.print("songList.contains(new Song(\"Be Kind\", \"Marshmello & Halsey\", \"2:53\"): ");
		oneSong = new Song("Be Kind", "Marshmello & Halsey", "2:53");
		System.out.println(songList.contains​(oneSong));
		System.out.println();
		System.out.println("---------------- Play Forward -----------------");
		System.out.println(songList.play());
		System.out.println();
		System.out.println("---------------- Play Backward -----------------");
		songList.switchPlayingDirection();
		System.out.println(songList.play());
		System.out.println("------------------------------------------------");
	}

	/**
	 * This method test and make use of the Song constructor, an accessor (getter)
	 * method, overridden method toString() and equal() method defined in the Song
	 * class.
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testSong() {
		Song song1 = new Song("Mojito", "Jay Chou", "3:05");
		Song song2 = new Song("Mojito", "Jay Chou", "2:10");
		Song song3 = new Song("Secret", "Jay Chou", "4:56");
		
		String song1Name = song1.getSongName();
		String song1Artist = song1.getArtist();
		String song1Duration = song1.getDuration();
		
		String song2Name = song2.getSongName();
		String song2Artist = song2.getArtist();
		String song2Duration = song2.getDuration();
		
		System.out.println("song 1 : "+song1);
		System.out.println("song 2 : "+song2);
		System.out.println("song 3 : "+song3);
		
		boolean result12 = song1.equals​(song2);
		boolean result13 = song1.equals​(song3);
		boolean testStatus = result12==true && result13==false;
		
		System.out.println("song 1 equals song 2 - "+result12);
		System.out.println("song 1 equals song 3 - "+result13);
		return testStatus;
	}

	/**
	 * This method test and make use of the LinkedNode constructor, an accessor
	 * (getter) method, and a mutator (setter) method defined in the LinkedCart
	 * class.
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testLinkedNode() {
		
		Song song11 = new Song("Mojito", "Jay Chou", "3:05");
		Song song21 = new Song("Mojito", "Jay Chou", "2:10");
		Song song31 = new Song("Secret", "Jay Chou", "4:56");
		
		LinkedNode node1 = new LinkedNode<Song>(null,song11,null);
		LinkedNode node2 = new LinkedNode<Song>(null,song21,null);
		LinkedNode node3 = new LinkedNode<Song>(null,song31,null);
		
		node1.setNext​(node2);
		node2.setPrev​(node1);
		node2.setNext​(node3);
		node3.setPrev​(node2);
		
		LinkedNode prevNode1 = node1.getPrev();
		LinkedNode nextNode3 = node3.getNext();
		
		Song song22 = (Song)node2.getData();
		Song song23 = (Song)node1.getNext().getData();
		Song song24 = (Song)node3.getPrev().getData();
		
		System.out.println("song 11 : "+song11);
		System.out.println("song 21 : "+song21);
		System.out.println("song 31 : "+song31);
		System.out.println("song 22 (from LinkedNode) : "+song22);
		System.out.println("song 23 (from LinkedNode>getNext) : "+song23);
		System.out.println("song 24 (from LinkedNode>getPrev) : "+song24);
		System.out.println("LinkedNode previous to Node 1 - "+prevNode1);
		System.out.println("LinkedNode next to Node 3 - "+nextNode3);
		
		boolean testStatus = song22.equals​(song23)&& song23.equals​(song24)
				&& prevNode1==null && nextNode3 == null;
		return testStatus;
	}

	/**
	 * This method checks for the correctness of addFirst(), addLast() and add(int
	 * index) method in SongPlayer class
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testSongPlayerAdd() {
		
		SongPlayer songList = new SongPlayer();
		songList.addFirst(new Song("Mojito", "Jay Chou", "3:05"));
		songList.addFirst(new Song("Secret", "Jay Chou", "4:56"));
		songList.addFirst(new Song("Clear Day", "Jay Chou", "4:59"));
		songList.addFirst(new Song("Dragon Fist", "Jay Chou", "4:32"));
		songList.addFirst(new Song("Out of Time", "The Weeknd", "3:34"));
		songList.addLast​(new Song("StarBoy", "The Weeknd", "3:50"));
		songList.addLast​(new Song("Save Your Tears", "The Weeknd", "3:35"));
		songList.add​(0, new Song("Simple Love", "Jay Chou", "4:30"));
		songList.add​(songList.size(), new Song("Superman Can’t Fly", "Jay Chou", "4:59"));
		
		boolean testStatus = songList.size()==9;
		return testStatus;
	}

	/**
	 * This method checks for the correctness of getFirst(), getLast() and get(int
	 * index) method in SongPlayer class
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testSongPlayerGet() {
		SongPlayer songList = new SongPlayer();
		Song song1 = new Song("Mojito", "Jay Chou", "3:05");
		Song song2 = new Song("Secret", "Jay Chou", "4:56");
		Song song3 = new Song("StarBoy", "The Weeknd", "3:50");
		Song song4 = new Song("Simple Love", "Jay Chou", "4:30");
		Song song5 = new Song("Superman Can’t Fly", "Jay Chou", "4:59");
		
		songList.addFirst(song1);
		System.out.println("addFirst : "+song1);
		System.out.println("getFirst : "+songList.getFirst());
		System.out.println("getLast : "+songList.getLast());
		
		songList.addFirst(song2);
		System.out.println("addFirst : "+song2);
		System.out.println("getFirst : "+songList.getFirst());
		System.out.println("getLast : "+songList.getLast());

		songList.addLast​(song3);
		System.out.println("addLast : "+song3);
		System.out.println("getFirst : "+songList.getFirst());
		System.out.println("getLast : "+songList.getLast());
		

		songList.add​(0,song4);
		System.out.println("add(index - 0): "+song4);
		System.out.println("getFirst : "+songList.getFirst());
		System.out.println("getLast : "+songList.getLast());
		
		songList.add​(songList.size(),song5);
		System.out.println("add(index - "+songList.size()+") : "+song5);
		System.out.println("getFirst : "+songList.getFirst());
		System.out.println("getLast : "+songList.getLast());
		
		boolean testStatus = songList.size()==5;
		return testStatus;

	}

	/**
	 * This method checks for the correctness of removeFirst(), removeLast() and
	 * remove(int index) method in SongPlayer class
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testSongPlayerRemove() {
		SongPlayer songList = new SongPlayer();
		Song song1 = new Song("Mojito", "Jay Chou", "3:05");
		Song song2 = new Song("Secret", "Jay Chou", "4:56");
		Song song3 = new Song("StarBoy", "The Weeknd", "3:50");
		Song song4 = new Song("Simple Love", "Jay Chou", "4:30");
		Song song5 = new Song("Superman Can’t Fly", "Jay Chou", "4:59");
		
		songList.addFirst(song1);
		System.out.println("addFirst : "+song1);
		songList.addFirst(song2);
		System.out.println("addFirst : "+song2);
		songList.addLast​(song3);
		System.out.println("addLast : "+song3);
		songList.add​(0,song4);
		System.out.println("add(index - 0): "+song4);
		songList.add​(songList.size(),song5);
		System.out.println("add(index - "+songList.size()+") : "+song5);
		
		Song firstSong = songList.removeFirst();
		System.out.println("removeFirst - "+firstSong);
		System.out.println("getFirst : "+songList.getFirst());
		System.out.println("getLast : "+songList.getLast());
		
		Song lastSong = songList.removeLast();
		System.out.println("removeLast - "+lastSong);
		System.out.println("getFirst : "+songList.getFirst());
		System.out.println("getLast : "+songList.getLast());
		
		boolean testStatus = songList.size()==3;
		return testStatus;
	}

	/**
	 * This method checks for the correctness of iterator(),
	 * switchPlayingDirection() and String play() method in SongPlayer class
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testSongPlayerIterator() {
		return false;
	}

	/**
	 * This method checks for the correctness of contains(Object song), clear(),
	 * isEmpty()and size() method in SongPlayer class
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testSongPlayerCommonMethod() {
		return false;
	}

	/**
	 * This method checks for the correctness of ForwardSongIterator class
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testForwardSongIterator() {
		return false;
	}

	/**
	 * This method checks for the correctness of BackwardSongIterator class
	 * 
	 * @return true when this test verifies a correct functionality, and false
	 *         otherwise
	 */
	public static boolean testBackwardSongIterator() {
		return false;
	}

	/**
	 * This method calls all the test methods defined and implemented in your
	 * SongPlayerTester class.
	 * 
	 * @return true if all the test methods defined in this class pass, and false
	 *         otherwise.
	 */
	public static boolean runAllTests() {
		return false;
	}

}